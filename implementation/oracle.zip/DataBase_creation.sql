-- Drop tables if they exist
DROP TABLE IF EXISTS productMovement;
DROP TABLE IF EXISTS request;
DROP TABLE IF EXISTS stock;
DROP TABLE IF EXISTS zone;
DROP TABLE IF EXISTS product;
DROP TABLE IF EXISTS provider;

-- Create tables
CREATE TABLE provider(
    id INT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) PRIMARY KEY ,
    providerName VARCHAR2(255) NOT NULL,
    createdAt DATE NOT NULL
);

CREATE TABLE product(
    id INT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) PRIMARY KEY ,
    productName VARCHAR2(255) NOT NULL,
    description VARCHAR(255) NOT NULL,
    cost NUMBER(8, 2) NOT NULL CHECK (cost >=0),
    quantity INT DEFAULT 0 NOT NULL CHECK (quantity >= 0),
    height NUMBER(8, 2) NOT NULL CHECK (height >=0),
    length NUMBER(8, 2) NOT NULL CHECK (length >=0),
    weight NUMBER(8, 2) NOT NULL CHECK (weight >=0),
    width NUMBER(8, 2) NOT NULL CHECK (width >=0),
    providerId NUMBER(19) NOT NULL,
    FOREIGN KEY (providerId) REFERENCES provider(id)
);

CREATE TABLE zone(
    id INT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) PRIMARY KEY ,
    zoneName VARCHAR2(255) NOT NULL
);

CREATE TABLE stock(
    id INT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) PRIMARY KEY ,
    quantity NUMBER(19) NOT NULL,
    zoneId NUMBER(19) NOT NULL,
    productId NUMBER(19) NOT NULL,
    FOREIGN KEY (zoneId) REFERENCES zone(id),
    FOREIGN KEY (productId) REFERENCES product(id)
);

CREATE TABLE request(
    id INT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) PRIMARY KEY ,
    quantity NUMBER(19) NOT NULL CHECK (quantity > 0),
    productId NUMBER(19) NOT NULL,
    requestType VARCHAR2(3) NOT NULL CHECK (requestType IN ('in', 'out')),
    requestDate DATE NOT NULL,
    FOREIGN KEY (productId) REFERENCES product(id)
);

CREATE TABLE productMovement(
    id INT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) PRIMARY KEY ,
    stockId NUMBER(19) NOT NULL,
    oldQuantity NUMBER(19) NOT NULL CHECK (oldQuantity >= 0),
    requestQuantity INT NOT NULL CHECK (requestQuantity > 0),
    requestId NUMBER(19) NOT NULL,
    FOREIGN KEY (stockId) REFERENCES stock(id),
    FOREIGN KEY (requestId) REFERENCES request(id)
);

INSERT INTO zone (zoneName) VALUES ('Zone A');
INSERT INTO zone (zoneName) VALUES ('Zone B');
INSERT INTO zone (zoneName) VALUES ('Zone C');

-- Create dummy data for providers
INSERT INTO provider (providerName, createdAt)
VALUES ('Provider 1', SYSDATE); -- SYSDATE generates the current date/time

-- Create dummy data for products and assign keys to provider
INSERT INTO product (productName, description, cost, quantity, height, length, weight, width, providerId)
VALUES ('Product 1', 'Description of Product 1', 10.99, 0 , 5.0, 10.0, 0.5, 2.0, 1);

INSERT INTO product (productName, description, cost, quantity, height, length, weight, width, providerId)
VALUES ('Product 2', 'Description of Product 2', 20.99, 0 , 6.0, 12.0, 0.6, 2.5, 1);

INSERT INTO product (productName, description, cost, quantity, height, length, weight, width, providerId)
VALUES ('Product 3', 'Description of Product 3', 30.99, 0 , 7.0, 14.0, 0.7, 3.0, 1);

