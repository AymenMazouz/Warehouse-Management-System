CREATE OR REPLACE TYPE zone_quantity_type AS OBJECT (
    zone_id NUMBER,
    quantity NUMBER
);


CREATE OR REPLACE TYPE zone_quantity_list AS TABLE OF zone_quantity_type;

