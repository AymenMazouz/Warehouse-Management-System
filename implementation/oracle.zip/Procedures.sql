-- GET ALL PRODUCTS
CREATE OR REPLACE FUNCTION get_all_products
RETURN SYS_REFCURSOR
IS
    products_cursor SYS_REFCURSOR;
BEGIN
    -- Open a cursor to select all rows from the products table
    OPEN products_cursor FOR
    SELECT product.* , provider.* FROM product JOIN provider on product.providerid = provider.id;
    
    -- Return the cursor
    RETURN products_cursor;
END;
/

-- GET ALL ZONES

CREATE OR REPLACE FUNCTION get_all_zones
RETURN SYS_REFCURSOR
IS
    zones_cursor SYS_REFCURSOR;
BEGIN
    -- Open a cursor to select all rows from the zones table
    OPEN zones_cursor FOR
    SELECT * FROM zone;
    
    -- Return the cursor
    RETURN zones_cursor;
END;
/

-- GET ALL PROVIDERS

CREATE OR REPLACE FUNCTION get_all_providers
RETURN SYS_REFCURSOR
IS
    providers_cursor SYS_REFCURSOR;
BEGIN
    -- Open a cursor to select all rows from the provider table
    OPEN providers_cursor FOR
    SELECT * FROM provider;
    
    -- Return the cursor
    RETURN providers_cursor;
END;
/
-- GET ALL STOCKS 
CREATE OR REPLACE FUNCTION get_all_stocks
RETURN SYS_REFCURSOR
IS
    stocks_cursor SYS_REFCURSOR;
BEGIN
    -- Open a cursor to select all rows from the stock table
    OPEN stocks_cursor FOR
SELECT 
stock_zone_query.* , productName , providerName , providerId
FROM 
    (SELECT s.id AS stockId, s.quantity stockQuantity , z.zonename, s.productId FROM stock s JOIN zone z ON s.zoneId = z.id) stock_zone_query
JOIN 
    product p ON p.id = stock_zone_query.productId
JOIN 
    provider pr ON pr.id = p.providerId;

    
    -- Return the cursor
    RETURN stocks_cursor;
END;
/

-- GET ALL REQUESTS 

CREATE OR REPLACE FUNCTION get_all_requests
RETURN SYS_REFCURSOR
IS
    requests_cursor SYS_REFCURSOR;
BEGIN
    -- Open a cursor to select all rows from the request table
    OPEN requests_cursor FOR
    SELECT request.requestType , request.quantity requestQuantity, productId  ,request.requestDate , providerName,   product.* FROM (request join product on request.productId = product.id)
   join
   provider pr ON pr.id = product.providerId;
    
    -- Return the cursor
    RETURN requests_cursor;
END;
/
----------------------------

-- GET ALL PRODUCT MOVEMENTS 
CREATE OR REPLACE FUNCTION get_all_product_movements
RETURN SYS_REFCURSOR
IS
    movements_cursor SYS_REFCURSOR;
BEGIN
    -- Open a cursor to select all rows from the productMovement table
    OPEN movements_cursor FOR
    SELECT * FROM productMovement;
    
    -- Return the cursor
    RETURN movements_cursor;
END;
/

-- get Detailed history  select * from product Movement .

CREATE OR REPLACE FUNCTION get_detailed_history(productId_input IN NUMBER)
RETURN SYS_REFCURSOR
IS
    summary_cursor SYS_REFCURSOR;
    product_exists NUMBER;
BEGIN
    -- Verify if the product exists
    SELECT COUNT(*) INTO product_exists FROM product WHERE id = productId_input;
    IF product_exists = 0 THEN
        -- Product does not exist
        RETURN NULL;
    ELSE
        -- Product exists, retrieve summary history
        OPEN summary_cursor FOR
        
SELECT 
    PM.id AS movementId,
    PM.oldQuantity AS oldQuantity,
    PM.requestQuantity AS requestQuantity,
    R.id AS requestId,
    R.quantity AS requestQuantity,
    R.requestType AS requestType,
    R.requestDate AS requestDate,
    S.id AS stockId,
    S.quantity AS stockQuantity,
    Z.id AS zoneId,
    Z.zoneName AS zoneName,
    P.id AS productId,
    P.productName AS productName,
    P.description AS productDescription,
    P.cost AS productCost,
    P.quantity AS productQuantity,
    P.height AS productHeight,
    P.length AS productLength,
    P.weight AS productWeight,
    P.width AS productWidth,
    PR.id AS providerId,
    PR.providerName AS providerName,
    PR.createdAt AS providerCreatedAt
FROM 
    productMovement PM
JOIN 
    request R ON PM.requestId = R.id
JOIN 
    stock S ON PM.stockId = S.id
JOIN 
    zone Z ON S.zoneId = Z.id
JOIN 
    product P ON S.productId = P.id
JOIN 
    provider PR ON P.providerId = PR.id
WHERE 
    P.id = productId_input;

        
        RETURN summary_cursor;
    END IF;
END;
/



CREATE OR REPLACE FUNCTION get_summary_history(productId_input IN NUMBER)
RETURN SYS_REFCURSOR
IS
    summary_cursor SYS_REFCURSOR;
    product_exists NUMBER;
BEGIN
    -- Verify if the product exists
    SELECT COUNT(*) INTO product_exists FROM product WHERE id = productId_input;
    IF product_exists = 0 THEN
        -- Product does not exist
        RETURN NULL;
    ELSE
        -- Product exists, retrieve summary history
        OPEN summary_cursor FOR
        
        SELECT req.* , provider.providerName
	FROM (
    	SELECT  request.* , product.cost , product.length , product.weight , product.width , product.productName , product.description ,  providerId 
    	FROM request
    	JOIN product ON request.productId = product.id
	) req
	JOIN provider ON provider.id = req.providerId
WHERE req.productId = productId_input;
        RETURN summary_cursor;
    END IF;
END;
/



--- PRODUCT INBOUND
CREATE OR REPLACE PROCEDURE product_inbound(
    productId_input IN NUMBER,
    zonesQuantities IN zone_quantity_list
)
IS
    total_quantity NUMBER := 0;
    requestId NUMBER;
    temporary_stock_id NUMBER;
    stock_quantity NUMBER;
    product_exists NUMBER;
    zone_exists NUMBER;
    stock_exists NUMBER :=0;
    -------------------
    
     temp_stock_id stock.id%TYPE; -- Variable to hold the stock ID
    temp_stock_quantity stock.quantity%TYPE; -- Variable to hold the stock quantity
    temp_stock_zone_id stock.zoneId%TYPE; -- Variable to hold the zone ID of the stock
BEGIN
    -- Verify if the product exists with the provided ID
    SELECT COUNT(*) INTO product_exists FROM product WHERE id = productId_input;
    IF product_exists = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Product with ID ' || productId_input || ' does not exist');
    END IF;

    -- Calculate total quantity
    FOR i IN 1..zonesQuantities.COUNT LOOP
        total_quantity := total_quantity + zonesQuantities(i).quantity;
    END LOOP;

    

    -- Create a new request entry for inbound products
    INSERT INTO request (quantity, productId, requestType, requestDate)
    VALUES (total_quantity, productId_input, 'in', SYSDATE)
    RETURNING id INTO requestId; -- Retrieve the requestId

    -- Iterate over the array of zone quantities
    FOR i IN 1..zonesQuantities.COUNT LOOP
        -- Accessing zone ID and quantity from the nested table
        DECLARE
            zone_id NUMBER;
            quantity NUMBER;
        BEGIN
            -- Extracting zone ID and quantity from the nested table
            zone_id := zonesQuantities(i).zone_id; -- Zone ID
            quantity := zonesQuantities(i).quantity; -- Quantity

            -- Verify if the zone exists
            SELECT COUNT(*) INTO zone_exists FROM zone WHERE id = zone_id;
              
            
            IF zone_exists = 0 THEN
                RAISE_APPLICATION_ERROR(-20002, 'Zone with ID ' || zone_id || ' does not exist');
            END IF;
                                                    
            -- Verify if stock exists for the product and zone
                        DBMS_OUTPUT.PUT_LINE('zone exists ' || zone_id );
                        DBMS_OUTPUT.PUT_LINE('prodcut exists ' || productId_input );



        SELECT COUNT(*) INTO stock_exists FROM stock WHERE (stock.productid = productId_input AND stock.zoneid= zone_id);                                                                              
            -- Log the result of the stock existence check
        IF stock_exists > 0 THEN
            DBMS_OUTPUT.PUT_LINE('Stock exists ' || stock_exists );
        ELSE
            DBMS_OUTPUT.PUT_LINE('Stock does not exist ' ||  stock_exists);
        END IF;
            --------------
            
            IF stock_exists = 0 THEN
                -- Insert new stock entry if it doesn't exist
                INSERT INTO stock (quantity, zoneId, productId)
                VALUES (0, zone_id, productId_input);
            END IF;

            -- Retrieve the stock ID and quantity
            SELECT id, quantity INTO temporary_stock_id, stock_quantity
            FROM stock 
            WHERE productId = productId_input 
            AND zoneId = zone_id;

            -- Insert into productMovement
            INSERT INTO productMovement (stockId, oldQuantity, requestQuantity, requestId)
            VALUES (temporary_stock_id, stock_quantity, quantity, requestId);

        END;
    END LOOP;

    -- Commit the transaction
    COMMIT;

    -- Logging for debugging
    DBMS_OUTPUT.PUT_LINE('Transaction committed successfully');

EXCEPTION
    WHEN OTHERS THEN
        -- Handle exceptions
        DBMS_OUTPUT.PUT_LINE('An error occurred: ' || SQLERRM);
        ROLLBACK;
        -- Logging for debugging
        DBMS_OUTPUT.PUT_LINE('Transaction rolled back');
END;
/



CREATE OR REPLACE FUNCTION product_outbound(
  productId_input IN NUMBER,
  requestedQuantity IN NUMBER
) RETURN SYS_REFCURSOR
IS
  result_outbound zone_quantity_list := zone_quantity_list(); -- Initialize the result variable
  stock_id NUMBER;
  zone_id NUMBER;
  removed_quantity NUMBER;
  quantity_untill_fulfilment NUMBER;
  stock_quantity NUMBER;
  remaining_quantity NUMBER := requestedQuantity; -- Initialize the remaining quantity
  

      CURSOR stock_cursor is 
      SELECT id, zoneId, quantity
      FROM stock
      WHERE productId = productId_input
      ORDER BY quantity DESC; -- Get stocks with the biggest quantity first
      
      
      
      RESULT_CURSOR SYS_REFCURSOR ;


BEGIN
  -- Check if the product exists and has sufficient quantity
  SELECT quantity INTO remaining_quantity
  FROM product
  WHERE id = productId_input;

  IF remaining_quantity IS NULL THEN
    -- Product not found
    RAISE_APPLICATION_ERROR(-20002, 'Product with ID: ' || TO_CHAR(productId_input) || ' not found');
  ELSIF remaining_quantity < requestedQuantity THEN
    -- Insufficient quantity available
    RAISE_APPLICATION_ERROR(-20002, 'Insufficient quantity for product ID: ' || TO_CHAR(productId_input) || '. Requested: ' || TO_CHAR(requestedQuantity) || ', Available: ' || TO_CHAR(remaining_quantity));
  ELSE
    -- Insert request record
    INSERT INTO request (quantity, productId, requestType, requestDate)
    VALUES (requestedQuantity, productId_input, 'out', SYSDATE);

    quantity_untill_fulfilment := requestedQuantity;

OPEN stock_cursor ;
    LOOP
      FETCH stock_cursor INTO stock_id, zone_id, stock_quantity;
      EXIT WHEN stock_cursor%NOTFOUND;

      IF quantity_untill_fulfilment <= 0 THEN
        -- Request fulfilled, no need to fetch more stocks
        EXIT;
      ELSIF stock_quantity >= quantity_untill_fulfilment THEN
        -- Remove requested quantity from current stock
        removed_quantity := quantity_untill_fulfilment;

        INSERT INTO productMovement (stockId, oldQuantity, requestQuantity, requestId)
        VALUES (stock_id, stock_quantity, removed_quantity, (SELECT MAX(id) FROM request WHERE productId = productId_input));

        -- Add the stock to the result
        result_outbound.extend;
        result_outbound(result_outbound.count) := zone_quantity_type(zone_id, removed_quantity);

        -- Update remaining quantity
        quantity_untill_fulfilment := 0;
      ELSE
        -- Remove all stock quantity
        removed_quantity := stock_quantity;

        INSERT INTO productMovement (stockId, oldQuantity, requestQuantity, requestId)
        VALUES (stock_id, stock_quantity, removed_quantity, (SELECT MAX(id) FROM request WHERE productId = productId_input));

        -- Add the stock to the result
        result_outbound.extend;
        result_outbound(result_outbound.count) := zone_quantity_type(zone_id, removed_quantity);

        -- Update remaining quantity
        quantity_untill_fulfilment := quantity_untill_fulfilment - stock_quantity;
      END IF;
    END LOOP;
  END IF;

  -- Commit the transaction if successful
  COMMIT;

  CLOSE stock_cursor; -- Close the cursor
  
  
  
  
  
  OPEN RESULT_CURSOR FOR
    SELECT zoneId, pm.requestQuantity AS quantity
    FROM productMovement pm
    JOIN stock s ON pm.stockId = s.id
    WHERE pm.requestId = (SELECT MAX(id) FROM request WHERE productId = productId_input);

  -- Return the cursor
  RETURN RESULT_CURSOR;
  



EXCEPTION
 WHEN NO_DATA_FOUND THEN
  DBMS_OUTPUT.PUT_LINE('Error: Product with ID ' || productId_input || ' not found.');


  WHEN OTHERS THEN
    -- Rollback if necessary
    ROLLBACK;
    -- Error handling
    RAISE;
END;
/


create or replace NONEDITIONABLE FUNCTION createProduct(
    p_productName IN VARCHAR2,
    p_description IN CLOB,
    p_cost IN NUMBER,
    p_quantity IN INT  ,  
    p_height IN NUMBER,
    p_length IN NUMBER,
    p_weight IN NUMBER,
    p_width IN NUMBER,
    p_providerId IN NUMBER
) RETURN INT IS
    v_productId INT;
BEGIN
    INSERT INTO product (productName, description, cost, quantity, height, length, weight, width, providerId)
    VALUES (p_productName, p_description, p_cost, p_quantity, p_height, p_length, p_weight, p_width, p_providerId)
    RETURNING id INTO v_productId;
    RETURN v_productId;
EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20002, 'Error in creating product: ' || SQLERRM);
END createProduct;
/


create or replace NONEDITIONABLE FUNCTION createProvider(
    p_providerName IN VARCHAR2,
    p_createdAt IN DATE
) RETURN INT IS
    v_providerId INT;
BEGIN
    INSERT INTO provider (providerName, createdAt) VALUES (p_providerName, p_createdAt) RETURNING id INTO v_providerId;
    RETURN v_providerId;
EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20003, 'Error in creating provider: ' || SQLERRM);
END createProvider;
/


create or replace NONEDITIONABLE FUNCTION createZone(
    p_zoneName IN VARCHAR2
) RETURN INT IS
    v_zoneId INT;
BEGIN
    INSERT INTO zone (zoneName) VALUES (p_zoneName) RETURNING id INTO v_zoneId;
    RETURN v_zoneId;
EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'Error in creating zone: ' || SQLERRM);
END createZone;
/





