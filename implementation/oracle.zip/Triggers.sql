CREATE OR REPLACE TRIGGER stock_modification_ofInbound_ofOutbound
AFTER INSERT ON productMovement
FOR EACH ROW
DECLARE
    v_request_type request.requestType%TYPE;
BEGIN
    -- Retrieve the request type for the new product movement
    SELECT r.requestType INTO v_request_type
    FROM request r
    WHERE r.id = :NEW.requestId;

    -- Check if the operation is an INSERT
    IF INSERTING THEN
        -- Check if the request type is "in"
        IF v_request_type = 'in' THEN
            -- Add the quantity to the stock
            UPDATE stock
            SET quantity = quantity + :NEW.requestQuantity
            WHERE id = :NEW.stockId;
        -- Check if the request type is "out"
        ELSIF v_request_type = 'out' THEN
            -- Subtract the quantity from the stock
            UPDATE stock
            SET quantity = quantity - :NEW.requestQuantity
            WHERE id = :NEW.stockId;
        END IF;
    END IF;
END;
/


CREATE OR REPLACE TRIGGER productQuantity_modification_Request
AFTER INSERT ON request
FOR EACH ROW
BEGIN
    -- Check if the request type is "in"
    IF :NEW.requestType = 'in' THEN
        -- Add the quantity to the product
        UPDATE product
        SET quantity = quantity + :NEW.quantity
        WHERE id = :NEW.productId;
    -- Check if the request type is "out"
    ELSIF :NEW.requestType = 'out' THEN
        -- Subtract the quantity from the product
        UPDATE product
        SET quantity = quantity - :NEW.quantity
        WHERE id = :NEW.productId;
    END IF;
END;
/

        
        
   