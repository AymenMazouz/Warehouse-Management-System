export type Zone = {
  id: number;
  name: string;
};
