export type Provider = {
  id: number;
  name: string;
  createdAt: Date;
};
